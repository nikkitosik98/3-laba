import org.junit.Test;

import static org.junit.Assert.*;

public class MatrixTest {
    @Test
    public void matrixDeterminant() throws Exception {
        Matrix mat = new Matrix(3, 1,2,3,4,5,6,7,8,9);
        double result = mat.matrixDeterminant();
        assertEquals(result,0, 0.001);
    }

}