
public abstract class InvertableMatrix implements IInvertableMatrix {

    public Matrix getInvertableMatrix(int size, Matrix matrix) throws NotInvertableMatrix {
        if ( matrix.matrixDeterminant() == 0){
                throw new NotInvertableMatrix();
        }
        Matrix invert = new Matrix(size);
        for (int i = 0; i < size; i++){
            invert.changeElem(i,i,1);
        }
        double koef;
        for (int i = 0; i < size; i++){
            for (int j = i + 1; j < size; j += 1){
                koef = matrix.getElem(i,j) / matrix.getElem(i,i);
                for (int k = i; k < size; k++){
                    matrix.changeElem(j,k,matrix.getElem(j,k)- koef * matrix.getElem(i,k));
                    invert.changeElem(j,k,invert.getElem(j,k)- koef * matrix.getElem(i,k));
                }
            }
        }
        return invert;
    }
}
