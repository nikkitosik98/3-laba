public interface IMatrix {
    public double getElem(int i, int j);
    public void changeElem(int i, int j, double elem);
    public double matrixDeterminant();
}
