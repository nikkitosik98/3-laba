public interface IInvertableMatrix {
    public Matrix getInvertableMatrix(int size) throws NotInvertableMatrix;
}
