import java.util.Arrays;

public class Matrix implements IMatrix {

    private double[] matrix;
    private int size;

    public Matrix(int size){
        this.size = size;
        matrix = new double[size*size];
    }

    public Matrix(int size, double ... items){
        this.size = (int)Math.sqrt(items.length);
        if (this.size*this.size != items.length || size != this.size){
            throw new IllegalArgumentException("Должно быть n^2 элементов!");
        }
        matrix = items;
    }

    public double getElem(int i, int j) {
        return this.matrix[i*size+j];
    }


    public void changeElem(int i, int j,double elem) {
        matrix[i*size+j] = elem;
    }


    public double matrixDeterminant() {
        double determinant = 1;
        double koef;
        for (int i = 0; i < size; i++){
            for (int j = i + 1; j < size; j += 1){
                koef = getElem(i,j) / getElem(i,i);
                for (int k = i; k < size; k++){
                    changeElem(j,k,getElem(j,k)- koef * getElem(i,k));
                }
            }
        }

        for (int i = 0;i < size; i++){
            determinant = determinant * getElem(i,i);
        }
        return determinant;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Matrix)) return false;

        Matrix matrix1 = (Matrix) o;

        return Arrays.equals(matrix, matrix1.matrix);
    }

    @Override
    public int hashCode() {
        return Arrays.hashCode(matrix);
    }
}
