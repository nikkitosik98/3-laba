public class NotInvertableMatrix extends Throwable {
    public NotInvertableMatrix() {
    }

    public NotInvertableMatrix(String message) {
        super(message);
    }

    public NotInvertableMatrix(String message, Throwable cause) {
        super(message, cause);
    }

    public NotInvertableMatrix(Throwable cause) {
        super(cause);
    }
}
